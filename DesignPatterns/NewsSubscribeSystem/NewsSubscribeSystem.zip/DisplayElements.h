#pragma once
class DisplayElements
{
public:
	DisplayElements() = default;
	virtual ~DisplayElements() = default;

	virtual void Display() = 0;
};

